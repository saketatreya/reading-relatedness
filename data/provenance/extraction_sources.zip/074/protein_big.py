"""exp 074 PROTEIN (scaled): ESM-2-650M, ~25 vertebrates across DEEP splits (mammal/bird/reptile/
amphibian/fish), ~15 conserved orthologs. Per-species vector = concat of per-gene z-normed mean
embeddings. Real molecular phylogeny, resource-balanced. PREDICT: low N + low C -> topology RECOVERS."""
import subprocess, sys, urllib.request, base64, io, time
import numpy as np
# (species, taxid, class, subgroup)
SP=[("human",9606,"Mammal","Euarch"),("chimp",9598,"Mammal","Euarch"),("gorilla",9595,"Mammal","Euarch"),
 ("macaque",9544,"Mammal","Euarch"),("mouse",10090,"Mammal","Euarch"),("rat",10116,"Mammal","Euarch"),
 ("rabbit",9986,"Mammal","Euarch"),
 ("dog",9615,"Mammal","Laura"),("cat",9685,"Mammal","Laura"),("ferret",9669,"Mammal","Laura"),
 ("cow",9913,"Mammal","Laura"),("pig",9823,"Mammal","Laura"),("sheep",9940,"Mammal","Laura"),
 ("horse",9796,"Mammal","Laura"),
 ("chicken",9031,"Bird","Galloanserae"),("turkey",9103,"Bird","Galloanserae"),("duck",8839,"Bird","Galloanserae"),
 ("anole",28377,"Reptile","Squamate"),
 ("xenopus",8364,"Amphibian","Anuran"),
 ("zebrafish",7955,"Fish","Otophysi"),("medaka",8090,"Fish","Atherinomorph"),("fugu",31033,"Fish","Percomorph"),
 ("tetraodon",99883,"Fish","Percomorph"),("cod",8049,"Fish","Gadiform"),("salmon",8030,"Fish","Protacanth")]
GENES=["CYCS","ACTB","GAPDH","TUBB","TP53","RHO","LDHA","ENO1","SOD1","ATP5F1A","PGK1","MDH1","TUBA1B","HSPA8","ALDOA"]

def fetch(gene,taxid):
    for rev in ("+AND+reviewed:true",""):
        url=(f"https://rest.uniprot.org/uniprotkb/search?query=gene:{gene}+AND+organism_id:{taxid}{rev}"
             f"&format=fasta&size=1")
        try:
            req=urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0"})
            txt=urllib.request.urlopen(req,timeout=30).read().decode()
            if txt.startswith(">"):
                seq="".join(txt.split("\n")[1:]).strip()
                if len(seq)>=30: return seq[:1022]
        except Exception: time.sleep(0.3)
    return None

def main():
    subprocess.run([sys.executable,"-m","pip","install","-q","transformers","sentencepiece"],check=False)
    import torch
    from transformers import AutoTokenizer, AutoModel
    dev="cuda" if torch.cuda.is_available() else "cpu"; print("device",dev,flush=True)
    print("fetching sequences from UniProt...",flush=True)
    seqs={}   # (species,gene)->seq
    for name,tax,_,_ in SP:
        got=0
        for g in GENES:
            s=fetch(g,tax)
            if s: seqs[(name,g)]=s; got+=1
        print(f"  {name}: {got}/{len(GENES)} genes",flush=True)
    tok=AutoTokenizer.from_pretrained("facebook/esm2_t33_650M_UR50D")
    model=AutoModel.from_pretrained("facebook/esm2_t33_650M_UR50D").eval().to(dev)
    emb={}
    uniq=list(seqs.items())
    for i in range(0,len(uniq),8):
        batch=uniq[i:i+8]; strs=[s for _,s in batch]
        enc=tok(strs,return_tensors="pt",padding=True,truncation=True,max_length=1024).to(dev)
        with torch.no_grad(): h=model(**enc).last_hidden_state
        am=enc["attention_mask"].unsqueeze(-1).float()
        v=((h*am).sum(1)/am.sum(1).clamp(min=1)).cpu().numpy()
        for (k,_),vec in zip(batch,v): emb[k]=vec
        print(".",end="",flush=True)
    print(flush=True); del model
    species=[s for s,_,_,_ in SP]; d=next(iter(emb.values())).shape[0]
    # concat of per-gene z-normed mean embeddings
    blocks={s:[] for s in species}
    for g in GENES:
        pres=[(s,emb[(s,g)]) for s in species if (s,g) in emb]
        if len(pres)<6: continue
        M=np.stack([v for _,v in pres]); M=(M-M.mean(0))/(M.std(0)+1e-6); dd={s:r for (s,_),r in zip(pres,M)}
        for s in species: blocks[s].append(dd.get(s,np.zeros(d)))
    X=np.stack([np.concatenate(blocks[s]) for s in species])
    lut={s:(cl,sg) for s,_,cl,sg in SP}
    levels=[(lut[s][0],lut[s][1],s) for s in species]   # class(deep), subgroup(shallow), species
    np.savez("protein_vectors.npz",X=X,species=np.array(species),levels=np.array(levels,dtype=object))
    buf=io.BytesIO(); np.savez(buf,X=X,species=np.array(species),levels=np.array(levels,dtype=object))
    print("VEC_B64_START"); print(base64.b64encode(buf.getvalue()).decode()); print("VEC_B64_END",flush=True)
    r=knob_report("PROTEIN ESM-2-650M (n=%d, %d classes)"%(len(species),len(set(l[0] for l in levels))),
                  X,levels,deep_depth=1,shallow_depth=2)
    print_report(r); print("\n=== STATUS: DONE ===")

# compact inlined two-knob analysis — appended into each domain script for jarvislabs self-containment.
import numpy as np
from itertools import combinations as _comb
class _N:
    def __init__(s,name=None,ch=None): s.name=name; s.ch=ch or []
    def leaves(s):
        st=[s]; o=[]
        while st:
            n=st.pop()
            if n.ch: st.extend(n.ch)
            else: o.append(n.name)
        return o
def _nj(labels,D):
    act=[_N(name=L) for L in labels]; Dm=D.astype(np.float64).copy(); np.fill_diagonal(Dm,0)
    while len(act)>2:
        m=len(act); rs=Dm.sum(1); Q=(m-2)*Dm-rs[:,None]-rs[None,:]; np.fill_diagonal(Q,np.inf)
        i,j=np.unravel_index(np.argmin(Q),Q.shape); i,j=(i,j) if i<j else (j,i)
        km=np.ones(m,bool); km[i]=km[j]=False; duk=0.5*(Dm[i,km]+Dm[j,km]-Dm[i,j])
        u=_N(ch=[act[i],act[j]]); na=[act[k] for k in range(m) if k!=i and k!=j]+[u]
        sub=Dm[np.ix_(km,km)]; mn=m-1; Dm=np.zeros((mn,mn)); Dm[:mn-1,:mn-1]=sub; Dm[:mn-1,mn-1]=duk; Dm[mn-1,:mn-1]=duk; act=na
    return _N(ch=act)
def _bips(node,allL):
    parts=set()
    def rec(n):
        for c in n.ch:
            lb=frozenset(c.leaves())
            if 1<len(lb)<len(allL): parts.add(lb)
            rec(c)
    rec(node); return parts
def _recov(labels,D,gold):
    if not gold: return float('nan')
    t=_nj(list(labels),D); allL=frozenset(labels); b=_bips(t,allL)
    return sum(1 for G in gold if G in b or (allL-G) in b)/len(gold)
def _euclid(X): return np.linalg.norm(X[:,None]-X[None],axis=2)
def _cosine(X):
    Xn=X/np.clip(np.linalg.norm(X,axis=1,keepdims=True),1e-9,None); D=1-Xn@Xn.T; np.fill_diagonal(D,0); return D
def _mantel(D,G):
    iu=np.triu_indices(D.shape[0],1); v1,v2=D[iu],G[iu]
    if v1.std()<1e-12 or v2.std()<1e-12: return 0.0
    return float(np.corrcoef(v1,v2)[0,1])
def _gold_from_levels(levels):
    n=len(levels); L=len(levels[0]); D=np.zeros((n,n))
    for i in range(n):
        for j in range(i+1,n):
            k=0
            while k<L and levels[i][k]==levels[j][k]: k+=1
            D[i,j]=D[j,i]=2*(L-k)
    return D
def _clades_at(labels,levels,depth):
    from collections import defaultdict
    g=defaultdict(list)
    for l,lv in zip(labels,levels): g[lv[:depth]].append(l)
    n=len(labels); return [frozenset(v) for v in g.values() if 1<len(v)<n]
def _nn_purity(D,labels,fine):
    f={l:x for l,x in zip(labels,fine)}; hit=0
    for i,l in enumerate(labels):
        d=D[i].copy(); d[i]=1e9; hit+=f[labels[int(np.argmin(d))]]==f[l]
    return hit/len(labels)
def _quartet_acc(D,Gold,nq=60000,seed=0):
    rng=np.random.default_rng(seed); n=D.shape[0]; ok=0; tot=0
    for _ in range(nq):
        q=rng.choice(n,4,replace=False); i,j,k,l=q
        gp=sorted([(Gold[i,j]+Gold[k,l],0),(Gold[i,k]+Gold[j,l],1),(Gold[i,l]+Gold[j,k],2)])
        if abs(gp[0][0]-gp[1][0])<1e-9: continue
        tot+=1
        dp=sorted([(D[i,j]+D[k,l],0),(D[i,k]+D[j,l],1),(D[i,l]+D[j,k],2)])
        if dp[0][1]==gp[0][1]: ok+=1
    return ok/max(tot,1), tot
def _delta_hyp(D,nq=20000,seed=0):
    rng=np.random.default_rng(seed); n=D.shape[0]; diam=D.max(); ds=[]
    for _ in range(nq):
        i,j,k,l=rng.choice(n,4,replace=False)
        s=sorted([D[i,j]+D[k,l],D[i,k]+D[j,l],D[i,l]+D[j,k]]); ds.append((s[2]-s[1])/2)
    return float(np.mean(ds)/(diam+1e-12))
def knob_report(name,X,levels,resource=None,deep_depth=1,shallow_depth=None):
    X=np.asarray(X,float); labels=list(range(len(X)))
    Ldepth=len(levels[0]); shallow_depth=shallow_depth or (Ldepth-1)
    Gold=_gold_from_levels(levels); De=_euclid(X); Dc=_cosine(X)
    deep=_clades_at(labels,levels,deep_depth); shal=_clades_at(labels,levels,shallow_depth)
    fine=[tuple(lv[:shallow_depth]) for lv in levels]; norms=np.linalg.norm(X,axis=1)
    me,mc=_mantel(De,Gold),_mantel(Dc,Gold); qa_c,ntot=_quartet_acc(Dc,Gold); qa_e,_=_quartet_acc(De,Gold)
    return {"name":name,"n":len(X),"N_normcv":float(norms.std()/(norms.mean()+1e-12)),
       "N_resource_corr":(float(np.corrcoef(norms,resource)[0,1]) if resource is not None else float('nan')),
       "N_cos_gain":mc-me,"C_quartet_acc_cos":qa_c,"C_quartet_acc_euc":qa_e,"C_nquartets":ntot,
       "C_delta_cos":_delta_hyp(Dc),"OUT_mantel_euc":me,"OUT_mantel_cos":mc,
       "OUT_deep_euc":_recov(labels,De,deep),"OUT_deep_cos":_recov(labels,Dc,deep),
       "OUT_shal_euc":_recov(labels,De,shal),"OUT_shal_cos":_recov(labels,Dc,shal),
       "OUT_nn_euc":_nn_purity(De,labels,fine),"OUT_nn_cos":_nn_purity(Dc,labels,fine),
       "n_deep":len(deep),"n_shal":len(shal)}
def print_report(r):
    print(f"\n===== KNOBS [{r['name']}]  n={r['n']} =====")
    print(f"  KNOB N (nuisance): norm-CV={r['N_normcv']:.2f}  corr(norm,resource)={r['N_resource_corr']:+.2f}  cosine-gain={r['N_cos_gain']:+.2f}")
    print(f"  KNOB C (contact):  quartet-acc cos={r['C_quartet_acc_cos']:.2f} euc={r['C_quartet_acc_euc']:.2f} (n={r['C_nquartets']}) delta={r['C_delta_cos']:.3f}")
    print(f"  OUT metric:   Mantel euc={r['OUT_mantel_euc']:+.2f} cos={r['OUT_mantel_cos']:+.2f}")
    print(f"  OUT topology: DEEP({r['n_deep']}) euc={r['OUT_deep_euc']:.2f}/cos={r['OUT_deep_cos']:.2f}  SHALLOW({r['n_shal']}) euc={r['OUT_shal_euc']:.2f}/cos={r['OUT_shal_cos']:.2f}")
    print(f"  OUT local:    NN euc={r['OUT_nn_euc']:.2f}/cos={r['OUT_nn_cos']:.2f}")
    print("  RESULT_JSON "+__import__("json").dumps(r))


if __name__=="__main__": main()

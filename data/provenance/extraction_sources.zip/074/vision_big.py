"""exp 074 VISION (scaled): DINOv2-base on CIFAR-100, ALL 100 test imgs/class, 3-level IMPOSED
taxonomy (metaclass -> superclass -> class). An imposed semantic taxonomy is inherently non-additive
(no clean tree). PREDICT: high C (low quartet-acc) even without 'contact' -> DEEP topology fails,
metric via cosine, local survives. Saves class centroids."""
import subprocess, sys, io, base64
from pathlib import Path
import numpy as np
MEAN=np.array([0.485,0.456,0.406],np.float32); STD=np.array([0.229,0.224,0.225],np.float32)
# CIFAR-100 coarse(0-19) -> metaclass
META={0:"ANIMAL",1:"ANIMAL",2:"PLANT",3:"HOUSE",4:"PLANT",5:"HOUSE",6:"HOUSE",7:"ANIMAL",8:"ANIMAL",
      9:"OUTDOOR",10:"OUTDOOR",11:"ANIMAL",12:"ANIMAL",13:"ANIMAL",14:"ANIMAL",15:"ANIMAL",16:"ANIMAL",
      17:"PLANT",18:"VEHICLE",19:"VEHICLE"}

def load_cifar100_test(cache):
    import pyarrow.parquet as pq
    from PIL import Image
    from huggingface_hub import hf_hub_download
    p=hf_hub_download(repo_id="uoft-cs/cifar100",filename="cifar100/test-00000-of-00001.parquet",
                      repo_type="dataset",cache_dir=cache)
    t=pq.read_table(p)
    imgs_b=t.column("img").to_pylist(); fine=t.column("fine_label").to_pylist(); coarse=t.column("coarse_label").to_pylist()
    imgs=[Image.open(io.BytesIO(x["bytes"])).convert("RGB") for x in imgs_b]
    return imgs,fine,coarse

def preprocess(pils):
    import torch
    arr=np.zeros((len(pils),3,224,224),np.float32)
    for k,im in enumerate(pils):
        a=(np.asarray(im.resize((224,224)),np.float32)/255.0-MEAN)/STD; arr[k]=a.transpose(2,0,1)
    return torch.from_numpy(arr)

def main():
    subprocess.run([sys.executable,"-m","pip","install","-q","transformers","pillow","pyarrow","huggingface_hub"],check=False)
    import torch
    from transformers import AutoModel
    dev="cuda" if torch.cuda.is_available() else "cpu"; print("device",dev,flush=True)
    model=AutoModel.from_pretrained("facebook/dinov2-base").eval().to(dev)
    imgs_all,fine,coarse=load_cifar100_test("cache")
    by={c:[] for c in range(100)}; fine2coarse={}
    for im,fl,cl in zip(imgs_all,fine,coarse):
        fine2coarse[fl]=cl; by[fl].append(im)
    H=model.config.hidden_size; C=np.zeros((100,H))
    for c in range(100):
        embs=[]; imgs=by[c]
        for i in range(0,len(imgs),64):
            with torch.no_grad():
                h=model(pixel_values=preprocess(imgs[i:i+64]).to(dev)).last_hidden_state[:,0]
            embs.append(h.float().cpu().numpy())
        C[c]=np.concatenate(embs).mean(0)
        if c%20==0: print(f"  class {c}",flush=True)
    levels=[(META[fine2coarse[c]],f"s{fine2coarse[c]}",f"c{c}") for c in range(100)]  # metaclass, superclass, class
    np.savez("vision_vectors.npz",X=C,levels=np.array(levels,dtype=object))
    buf=io.BytesIO(); np.savez(buf,X=C,levels=np.array(levels,dtype=object))
    print("VEC_B64_START"); print(base64.b64encode(buf.getvalue()).decode()); print("VEC_B64_END",flush=True)
    r=knob_report("VISION DINOv2 / CIFAR-100 (n=100, imposed taxonomy)",C,levels,deep_depth=1,shallow_depth=2)
    print_report(r); print("\n=== STATUS: DONE ===")

# compact inlined two-knob analysis — appended into each domain script for jarvislabs self-containment.
import numpy as np
from itertools import combinations as _comb
class _N:
    def __init__(s,name=None,ch=None): s.name=name; s.ch=ch or []
    def leaves(s):
        st=[s]; o=[]
        while st:
            n=st.pop()
            if n.ch: st.extend(n.ch)
            else: o.append(n.name)
        return o
def _nj(labels,D):
    act=[_N(name=L) for L in labels]; Dm=D.astype(np.float64).copy(); np.fill_diagonal(Dm,0)
    while len(act)>2:
        m=len(act); rs=Dm.sum(1); Q=(m-2)*Dm-rs[:,None]-rs[None,:]; np.fill_diagonal(Q,np.inf)
        i,j=np.unravel_index(np.argmin(Q),Q.shape); i,j=(i,j) if i<j else (j,i)
        km=np.ones(m,bool); km[i]=km[j]=False; duk=0.5*(Dm[i,km]+Dm[j,km]-Dm[i,j])
        u=_N(ch=[act[i],act[j]]); na=[act[k] for k in range(m) if k!=i and k!=j]+[u]
        sub=Dm[np.ix_(km,km)]; mn=m-1; Dm=np.zeros((mn,mn)); Dm[:mn-1,:mn-1]=sub; Dm[:mn-1,mn-1]=duk; Dm[mn-1,:mn-1]=duk; act=na
    return _N(ch=act)
def _bips(node,allL):
    parts=set()
    def rec(n):
        for c in n.ch:
            lb=frozenset(c.leaves())
            if 1<len(lb)<len(allL): parts.add(lb)
            rec(c)
    rec(node); return parts
def _recov(labels,D,gold):
    if not gold: return float('nan')
    t=_nj(list(labels),D); allL=frozenset(labels); b=_bips(t,allL)
    return sum(1 for G in gold if G in b or (allL-G) in b)/len(gold)
def _euclid(X): return np.linalg.norm(X[:,None]-X[None],axis=2)
def _cosine(X):
    Xn=X/np.clip(np.linalg.norm(X,axis=1,keepdims=True),1e-9,None); D=1-Xn@Xn.T; np.fill_diagonal(D,0); return D
def _mantel(D,G):
    iu=np.triu_indices(D.shape[0],1); v1,v2=D[iu],G[iu]
    if v1.std()<1e-12 or v2.std()<1e-12: return 0.0
    return float(np.corrcoef(v1,v2)[0,1])
def _gold_from_levels(levels):
    n=len(levels); L=len(levels[0]); D=np.zeros((n,n))
    for i in range(n):
        for j in range(i+1,n):
            k=0
            while k<L and levels[i][k]==levels[j][k]: k+=1
            D[i,j]=D[j,i]=2*(L-k)
    return D
def _clades_at(labels,levels,depth):
    from collections import defaultdict
    g=defaultdict(list)
    for l,lv in zip(labels,levels): g[lv[:depth]].append(l)
    n=len(labels); return [frozenset(v) for v in g.values() if 1<len(v)<n]
def _nn_purity(D,labels,fine):
    f={l:x for l,x in zip(labels,fine)}; hit=0
    for i,l in enumerate(labels):
        d=D[i].copy(); d[i]=1e9; hit+=f[labels[int(np.argmin(d))]]==f[l]
    return hit/len(labels)
def _quartet_acc(D,Gold,nq=60000,seed=0):
    rng=np.random.default_rng(seed); n=D.shape[0]; ok=0; tot=0
    for _ in range(nq):
        q=rng.choice(n,4,replace=False); i,j,k,l=q
        gp=sorted([(Gold[i,j]+Gold[k,l],0),(Gold[i,k]+Gold[j,l],1),(Gold[i,l]+Gold[j,k],2)])
        if abs(gp[0][0]-gp[1][0])<1e-9: continue
        tot+=1
        dp=sorted([(D[i,j]+D[k,l],0),(D[i,k]+D[j,l],1),(D[i,l]+D[j,k],2)])
        if dp[0][1]==gp[0][1]: ok+=1
    return ok/max(tot,1), tot
def _delta_hyp(D,nq=20000,seed=0):
    rng=np.random.default_rng(seed); n=D.shape[0]; diam=D.max(); ds=[]
    for _ in range(nq):
        i,j,k,l=rng.choice(n,4,replace=False)
        s=sorted([D[i,j]+D[k,l],D[i,k]+D[j,l],D[i,l]+D[j,k]]); ds.append((s[2]-s[1])/2)
    return float(np.mean(ds)/(diam+1e-12))
def knob_report(name,X,levels,resource=None,deep_depth=1,shallow_depth=None):
    X=np.asarray(X,float); labels=list(range(len(X)))
    Ldepth=len(levels[0]); shallow_depth=shallow_depth or (Ldepth-1)
    Gold=_gold_from_levels(levels); De=_euclid(X); Dc=_cosine(X)
    deep=_clades_at(labels,levels,deep_depth); shal=_clades_at(labels,levels,shallow_depth)
    fine=[tuple(lv[:shallow_depth]) for lv in levels]; norms=np.linalg.norm(X,axis=1)
    me,mc=_mantel(De,Gold),_mantel(Dc,Gold); qa_c,ntot=_quartet_acc(Dc,Gold); qa_e,_=_quartet_acc(De,Gold)
    return {"name":name,"n":len(X),"N_normcv":float(norms.std()/(norms.mean()+1e-12)),
       "N_resource_corr":(float(np.corrcoef(norms,resource)[0,1]) if resource is not None else float('nan')),
       "N_cos_gain":mc-me,"C_quartet_acc_cos":qa_c,"C_quartet_acc_euc":qa_e,"C_nquartets":ntot,
       "C_delta_cos":_delta_hyp(Dc),"OUT_mantel_euc":me,"OUT_mantel_cos":mc,
       "OUT_deep_euc":_recov(labels,De,deep),"OUT_deep_cos":_recov(labels,Dc,deep),
       "OUT_shal_euc":_recov(labels,De,shal),"OUT_shal_cos":_recov(labels,Dc,shal),
       "OUT_nn_euc":_nn_purity(De,labels,fine),"OUT_nn_cos":_nn_purity(Dc,labels,fine),
       "n_deep":len(deep),"n_shal":len(shal)}
def print_report(r):
    print(f"\n===== KNOBS [{r['name']}]  n={r['n']} =====")
    print(f"  KNOB N (nuisance): norm-CV={r['N_normcv']:.2f}  corr(norm,resource)={r['N_resource_corr']:+.2f}  cosine-gain={r['N_cos_gain']:+.2f}")
    print(f"  KNOB C (contact):  quartet-acc cos={r['C_quartet_acc_cos']:.2f} euc={r['C_quartet_acc_euc']:.2f} (n={r['C_nquartets']}) delta={r['C_delta_cos']:.3f}")
    print(f"  OUT metric:   Mantel euc={r['OUT_mantel_euc']:+.2f} cos={r['OUT_mantel_cos']:+.2f}")
    print(f"  OUT topology: DEEP({r['n_deep']}) euc={r['OUT_deep_euc']:.2f}/cos={r['OUT_deep_cos']:.2f}  SHALLOW({r['n_shal']}) euc={r['OUT_shal_euc']:.2f}/cos={r['OUT_shal_cos']:.2f}")
    print(f"  OUT local:    NN euc={r['OUT_nn_euc']:.2f}/cos={r['OUT_nn_cos']:.2f}")
    print("  RESULT_JSON "+__import__("json").dumps(r))


if __name__=="__main__": main()

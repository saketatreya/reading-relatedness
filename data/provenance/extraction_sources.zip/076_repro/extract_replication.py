"""076_repro / extract_replication -- WP1 job 2: the exp-043 model-generality recipe
on the consolidated 89-language set. mBERT / XLM-R-base / LaBSE, mean_pool at
layers {nl//2, 3nl//4} (043 convention), float32. Same centroid/alignment scheme
as extract_language.py. Output: $OUT/replication_reps.npz.
"""
import json, os, subprocess, sys, tarfile, time, urllib.request
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from langset import LANGS, FAM63, FAM88, N, NTRAIN, short  # noqa: E402
from hub import hub_align  # noqa: E402

FLORES_URL = "https://dl.fbaipublicfiles.com/nllb/flores200_dataset.tar.gz"
MODELS = [("mbert", "bert-base-multilingual-cased"),
          ("xlmr_base", "xlm-roberta-base"),
          ("labse", "sentence-transformers/LaBSE")]
MAXLEN = 256
BATCH = int(os.environ.get("BATCH", "32"))
OUT = Path(os.environ.get("OUT", "/home/out"))


def get_flores() -> Path:
    root = Path("flores200_dataset")
    if not root.exists():
        tgz = Path("f.tgz")
        if not tgz.exists():
            req = urllib.request.Request(FLORES_URL, headers={"User-Agent": "Mozilla/5.0"})
            tgz.write_bytes(urllib.request.urlopen(req, timeout=600).read())
        with tarfile.open(tgz) as t:
            t.extractall(".")
    return root / "devtest"


def _extract_worker(dev, hf_id, layers, my_codes, lines, reps, prog, lock, t0, key, total, errs):
    """Per-device worker: own tokenizer+model copy, fills reps[L][c] for its
    language shard (distinct keys -> thread-safe). Estimand-identical to the
    single-GPU loop; multi-GPU (Kaggle T4 x2) just shards languages."""
    try:
        import torch
        from transformers import AutoModel, AutoTokenizer
        tok = AutoTokenizer.from_pretrained(hf_id)
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token
        model = AutoModel.from_pretrained(
            hf_id, torch_dtype=torch.float32, output_hidden_states=True
        ).eval().to(dev)
        d = model.config.hidden_size
        specials = set(tok.all_special_ids)
        for c in my_codes:
            ls = lines[c]
            acc = {L: np.zeros((N, d), np.float32) for L in layers}
            for i in range(0, N, BATCH):
                enc = tok(ls[i:i + BATCH], return_tensors="pt", padding=True,
                          truncation=True, max_length=MAXLEN).to(dev)
                with torch.no_grad():
                    hs = model(**enc).hidden_states
                m = enc["attention_mask"].float()
                for sid in specials:
                    m[enc["input_ids"] == sid] = 0.0
                mm = m.unsqueeze(-1)
                for L in layers:
                    h = hs[L + 1]
                    acc[L][i:i + h.shape[0]] = (
                        (h * mm).sum(1) / mm.sum(1).clamp(min=1)).cpu().numpy()
            with lock:
                for L in layers:
                    reps[L][c] = acc[L]
                prog[0] += 1
                if prog[0] % 20 == 0 or prog[0] == total:
                    print(f"  [{key}] {prog[0]}/{total} ({time.time()-t0:.0f}s)", flush=True)
        del model
        if str(dev).startswith("cuda"):
            torch.cuda.empty_cache()
    except Exception as e:  # surface in main; a silent dead thread would corrupt the cache
        errs.append((dev, e))
        raise


def main():
    t0 = time.time()
    OUT.mkdir(parents=True, exist_ok=True)
    subprocess.run([sys.executable, "-m", "pip", "install", "-q",
                    "transformers", "sentencepiece"], check=False)
    import torch
    from transformers import AutoModel, AutoTokenizer

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    if dev != "cuda" and os.environ.get("ALLOW_CPU", "") != "1":
        raise SystemExit("refusing to run on CPU (set ALLOW_CPU=1 to override)")

    dd = get_flores()
    codes = [c for c, _, _, _ in LANGS]
    lines = {}
    for c in codes:
        f = dd / f"{c}.devtest"
        assert f.exists(), f"FLORES missing {c}"
        ls = f.read_text(errors="ignore").splitlines()[:N]
        assert len(ls) == N, (c, len(ls))
        lines[c] = ls
    print(f"loaded {len(codes)} languages", flush=True)

    famA = {f: [c for c in codes if short(c) in ms] for f, ms in FAM63.items()}
    arrs = {"codes": np.array(codes),
            "levels": np.array([(mf, br, ge, c) for c, mf, br, ge in LANGS])}
    for f, ms in famA.items():
        arrs[f"famA_members_{f}"] = np.array(ms)
    for f, ms in FAM88.items():
        arrs[f"famB_members_{f}"] = np.array(ms)
    model_layers = {}

    import threading
    from transformers import AutoConfig
    ngpu = torch.cuda.device_count() if dev == "cuda" else 0
    devs = [f"cuda:{i}" for i in range(ngpu)] or ["cpu"]
    print(f"extraction devices: {devs}", flush=True)

    for key, hf_id in MODELS:
        nl = AutoConfig.from_pretrained(hf_id).num_hidden_layers
        layers = sorted({nl // 2, (3 * nl) // 4})
        model_layers[key] = layers
        print(f"[{key}] {hf_id} nl={nl} layers={layers}", flush=True)

        reps = {L: {} for L in layers}
        prog, lock, errs = [0], threading.Lock(), []
        if len(devs) == 1:
            _extract_worker(devs[0], hf_id, layers, codes, lines, reps,
                            prog, lock, t0, key, len(codes), errs)
        else:
            shards = [codes[i::len(devs)] for i in range(len(devs))]
            ths = [threading.Thread(target=_extract_worker,
                                    args=(dv, hf_id, layers, sh, lines, reps,
                                          prog, lock, t0, key, len(codes), errs))
                   for dv, sh in zip(devs, shards)]
            for th in ths:
                th.start()
            for th in ths:
                th.join()
        if errs:
            raise RuntimeError(f"[{key}] worker failed on {errs[0][0]}: {errs[0][1]!r}")
        assert all(len(reps[L]) == len(codes) for L in layers), f"[{key}] incomplete extraction"

        for L in layers:
            cfg = f"{key}_L{L:02d}"
            R = reps[L]
            arrs[f"raw_{cfg}"] = np.stack(
                [R[c][NTRAIN:].mean(0) for c in codes]).astype(np.float32)
            aligned, gm, _ = hub_align(R, n_train=NTRAIN)
            arrs[f"glob_{cfg}"] = np.stack(
                [aligned[c][NTRAIN:].mean(0) - gm for c in codes]).astype(np.float32)
            for tag, famset in (("famA", famA), ("famB", FAM88)):
                for f, ms in famset.items():
                    al, g, _ = hub_align({c: R[c] for c in ms}, n_train=NTRAIN)
                    arrs[f"{tag}_{f}_{cfg}"] = np.stack(
                        [al[c][NTRAIN:].mean(0) - g for c in ms]).astype(np.float32)
            print(f"aligned {cfg} ({time.time()-t0:.0f}s)", flush=True)
        del reps

    meta = dict(models={k: dict(hf_id=h, layers=model_layers[k]) for k, h in MODELS},
                dtype="float32", maxlen=MAXLEN, batch=BATCH, pool="mean_pool",
                layer_convention="layer_K == hidden_states[K+1] (block K output)",
                centroid="test-split (last 200) mean; aligned variants minus grand mean",
                n=N, ntrain=NTRAIN, date="2026-08-24")
    arrs["meta"] = np.array(json.dumps(meta))
    out = OUT / "replication_reps.npz"
    np.savez_compressed(out, **arrs)
    print(f"wrote {out} ({out.stat().st_size/1e6:.1f} MB)", flush=True)
    print(f"=== STATUS: DONE ({time.time()-t0:.0f}s) ===", flush=True)


if __name__ == "__main__":
    main()

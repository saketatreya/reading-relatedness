"""076_repro / extract_speech -- WP1 job 3: the exp-068 SPEECH phase (wav2vec2-XLS-R\non FLEURS), unchanged except that per-language centroids are saved to $OUT/speech_vectors.npz\n(the 068 run left no artifact on disk). Original docstring follows.\n\n"""
"""exp 068 SPEECH domain (wav2vec2-XLS-R self-supervised speech). FLEURS (speech twin of FLORES):
same sentences spoken per language. Per-language centroid = mean-pooled XLS-R embedding over
utterances. Three-tier metric-vs-topology vs language FAMILY. Self-contained for jarvislabs GPU."""
import subprocess, sys
# Stream FLEURS from its PARQUET export (fetch only the ~N_UTT rows we use) instead of the loading
# script downloading a whole per-language audio archive. Latest datasets + no trust_remote_code.
subprocess.run([sys.executable,"-m","pip","install","-q","transformers","datasets","soundfile","librosa","torch","huggingface_hub"],check=False)
from collections import defaultdict
import numpy as np

# (FLEURS config, family)
LANGS=[("en_us","Germanic"),("de_de","Germanic"),("nl_nl","Germanic"),("sv_se","Germanic"),("da_dk","Germanic"),("is_is","Germanic"),
       ("fr_fr","Romance"),("it_it","Romance"),("es_419","Romance"),("pt_br","Romance"),("ro_ro","Romance"),("ca_es","Romance"),
       ("ru_ru","Slavic"),("uk_ua","Slavic"),("bg_bg","Slavic"),("pl_pl","Slavic"),("cs_cz","Slavic"),("sk_sk","Slavic"),
       ("hi_in","IndoAryan"),("bn_in","IndoAryan"),("mr_in","IndoAryan"),("gu_in","IndoAryan"),
       ("tr_tr","Turkic"),("uz_uz","Turkic"),("kk_kz","Turkic"),("az_az","Turkic"),
       ("ar_eg","Semitic"),("he_il","Semitic"),("am_et","Semitic"),("mt_mt","Semitic")]
N_UTT=100          # was 40; centroid noise dominated the between-language spread
LAYERS=[6,12,18,24] # XLS-R-300m has 24 blocks; layer_K == hidden_states[K] here,
                    # K=24 being the old last_hidden_state. Text got a 4-layer
                    # sweep, so speech gets one too (reliability matching).
IE={"Romance","Germanic","Slavic","IndoAryan"}

# ---- inlined three-tier helpers ----
class Node:
    def __init__(s,name=None,children=None): s.name=name; s.children=children or []
    def leaves(s):
        if not s.children: return [s.name]
        o=[]; [o.extend(c.leaves()) for c in s.children]; return o
def nj(labels,D):
    n=len(labels); act=[Node(name=L) for L in labels]; Dm=D.astype(float).copy(); np.fill_diagonal(Dm,0)
    while len(act)>2:
        m=len(act); rs=Dm.sum(1); Q=(m-2)*Dm-rs[:,None]-rs[None,:]; np.fill_diagonal(Q,np.inf)
        i,j=np.unravel_index(np.argmin(Q),Q.shape); i,j=(i,j) if i<j else (j,i)
        km=np.ones(m,bool); km[i]=km[j]=False; duk=0.5*(Dm[i,km]+Dm[j,km]-Dm[i,j])
        u=Node(children=[act[i],act[j]]); na=[act[k] for k in range(m) if k!=i and k!=j]+[u]
        sub=Dm[np.ix_(km,km)]; mn=m-1; Dm=np.zeros((mn,mn)); Dm[:mn-1,:mn-1]=sub; Dm[:mn-1,mn-1]=duk; Dm[mn-1,:mn-1]=duk; act=na
    return Node(children=act)
def bips(node,allL):
    parts=[]
    def rec(n):
        if not n.children: return
        for c in n.children:
            lb=frozenset(c.leaves())
            if 1<len(lb)<len(allL): parts.append(lb)
            rec(c)
    rec(node); return parts
def mantel(D1,D2,n_perms=2000,seed=0):
    n=D1.shape[0]; iu=np.triu_indices(n,1); v1,v2=D1[iu],D2[iu]; r=float(np.corrcoef(v1,v2)[0,1])
    rng=np.random.default_rng(seed); c=0
    for _ in range(n_perms):
        p=rng.permutation(n)
        if abs(np.corrcoef(v1,D2[np.ix_(p,p)][iu])[0,1])>=abs(r): c+=1
    return r,c/n_perms
def gold_from_groups(g,sup):
    n=len(g); D=np.zeros((n,n))
    for i in range(n):
        for j in range(n):
            D[i,j]=0 if i==j else (1 if g[i]==g[j] else (2 if sup[i]==sup[j] else 3))
    return D
def clades(labels,g,sup):
    cl=[frozenset(l for l,x in zip(labels,g) if x==G) for G in sorted(set(g))]
    cl+=[frozenset(l for l,x in zip(labels,sup) if x==S) for S in sorted(set(sup))]
    return [c for c in cl if 1<len(c)<len(labels)]
def dmat(C,kind):
    if kind=="euclid": return np.linalg.norm(C[:,None]-C[None],axis=2)
    if kind=="sq_euclid": return np.linalg.norm(C[:,None]-C[None],axis=2)**2
    Cn=C/np.clip(np.linalg.norm(C,axis=1,keepdims=True),1e-9,None); D=1-Cn@Cn.T; np.fill_diagonal(D,0); return D
def recovered(labels,D,cl):
    t=nj(list(labels),D); allL=frozenset(labels); b=set(bips(t,allL))
    return sum(1 for G in cl if G in b or (allL-G) in b), len(cl)
def nn_pur(D,g):
    hit=0
    for i in range(len(g)):
        d=D[i].copy(); d[i]=1e9; hit+=g[int(np.argmin(d))]==g[i]
    return hit/len(g)
def probe_loo(C,labels,g,gold,dims=(8,12)):
    Cc=C-C.mean(0); _,_,Vt=np.linalg.svd(Cc,full_matrices=False); res={}
    for k in dims:
        if k>=min(Cc.shape): continue
        Z=Cc@Vt[:k].T; n=Z.shape[0]; iu=np.triu_indices(k)
        def feat(a,b): dd=Z[a]-Z[b]; return (np.outer(dd,dd)*(2-np.eye(k)))[iu]
        rec=[]
        for G in sorted(set(g)):
            ti=[i for i,x in enumerate(g) if x==G]
            if len(ti)<2: continue
            tr=[(i,j) for i in range(n) for j in range(i+1,n) if g[i]!=G and g[j]!=G]
            X=np.array([feat(i,j) for i,j in tr]); t=np.array([gold[i,j] for i,j in tr]); w,*_=np.linalg.lstsq(X,t,rcond=None)
            D=np.zeros((n,n))
            for i in range(n):
                for j in range(i+1,n): D[i,j]=D[j,i]=np.sqrt(max(feat(i,j)@w,0.0))
            tt=nj(list(labels),D); allL=frozenset(labels); b=set(bips(tt,allL)); Gs=frozenset(labels[i] for i in ti)
            rec.append(1.0 if (Gs in b or (allL-Gs) in b) else 0.0)
        res[k]=(float(np.mean(rec)),len(rec))
    return res

def main():
    import torch
    from datasets import load_dataset
    from transformers import AutoModel, AutoFeatureExtractor
    dev="cuda" if torch.cuda.is_available() else "cpu"; print("device",dev,flush=True)
    fe=AutoFeatureExtractor.from_pretrained("facebook/wav2vec2-xls-r-300m")
    model=AutoModel.from_pretrained("facebook/wav2vec2-xls-r-300m",
                                    output_hidden_states=True).eval().to(dev)

    def frame_lens(am,nframes):
        """Sample-domain mask -> FRAME-domain lengths. The v1 run sliced the
        frame tensor with a sample count (~160k vs ~500 frames), so every padded
        silence frame entered the mean pool and homogenised the centroids."""
        slen=am.sum(-1)
        try:
            fl=model._get_feat_extract_output_lengths(slen)
            fl=fl.to(torch.long).clamp(min=1,max=nframes)
        except Exception:      # proportional fallback if the private API moves
            fl=(slen.float()/am.shape[-1]*nframes).round().long().clamp(min=1,max=nframes)
        return fl

    labels=[]; fams=[]; sups=[]; Cl={L:[] for L in LAYERS}
    for cfg,fam in LANGS:
        try:
            ds=load_dataset("google/fleurs",cfg,split="test",streaming=True)  # parquet streaming
            vecs={L:[] for L in LAYERS}; buf=[]
            for i,ex in enumerate(ds):
                if i>=N_UTT: break
                buf.append(ex["audio"]["array"])
            for k in range(0,len(buf),8):    # batch GPU inference
                b=buf[k:k+8]
                enc=fe(b,sampling_rate=16000,return_tensors="pt",padding=True)
                iv=enc.input_values.to(dev); am=enc.get("attention_mask")
                with torch.no_grad():
                    hs=model(iv,attention_mask=am.to(dev) if am is not None else None).hidden_states
                nf=hs[0].shape[1]
                fl=frame_lens(am,nf) if am is not None else torch.full((iv.shape[0],),nf)
                for L in LAYERS:
                    h=hs[L]
                    for r in range(h.shape[0]):
                        vecs[L].append(h[r,:int(fl[r])].mean(0).float().cpu().numpy())
            if len(vecs[LAYERS[0]])<10: print(f"  {cfg}: only {len(vecs[LAYERS[0]])} utts, skip",flush=True); continue
            for L in LAYERS: Cl[L].append(np.mean(vecs[L],0))
            labels.append(cfg); fams.append(fam); sups.append(fam if fam in IE else fam)
            print(f"  {cfg} ({fam}): {len(vecs[LAYERS[0]])} utts",flush=True)
        except Exception as e:
            print(f"  {cfg} FAILED: {repr(e)[:100]}",flush=True)
    Cl={L:np.array(v) for L,v in Cl.items()}
    C=Cl[12]     # alias: the mid-stack layer, the informative one for XLS-R
    import os as _os
    from pathlib import Path as _P
    _out=_P(_os.environ.get("OUT","/home/out")); _out.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(_out/"speech_vectors.npz",C=C,labels=np.array(labels),fams=np.array(fams),
                        layers=np.array(LAYERS),n_utt=N_UTT,
                        **{f"C_L{L:02d}":Cl[L] for L in LAYERS})
    print(f"saved {_out}/speech_vectors.npz {C.shape} layers={LAYERS} n_utt={N_UTT}",flush=True)
    for L in LAYERS:   # degeneracy check: v1 gave mean pairwise cos 0.985, PR 2.5
        X=Cl[L]; Xn=X/np.linalg.norm(X,axis=1,keepdims=True); S=Xn@Xn.T
        off=S[np.triu_indices(len(X),1)]
        Xc=X-X.mean(0); sv=np.linalg.svd(Xc,compute_uv=False)
        prat=(sv**2).sum()**2/(sv**4).sum()
        print(f"  L{L:02d} mean pairwise cos {off.mean():+.4f}  participation ratio {prat:.2f}",flush=True)
    sups=[(f if f in IE else f) for f in fams]
    supg=["IE" if f in IE else f for f in fams]
    gold=gold_from_groups(fams,supg); cl=clades(labels,fams,supg)
    out=[f"=== THREE-TIER [SPEECH wav2vec2-XLS-R / FLEURS] n={len(labels)} languages, "
         f"{len(set(fams))} families, {N_UTT} utts/lang, layer sweep ==="]
    out.append("  TIER1 unsupervised: metric -> Mantel(D,gold) | exact clades | NN same-family purity")
    for L in LAYERS:
        for kind in ["euclid","cosine"]:
            D=dmat(Cl[L],kind); r,p=mantel(D,gold,2000); h,tot=recovered(labels,D,cl); pur=nn_pur(D,fams)
            out.append(f"    L{L:02d} {kind:<8} r={r:+.3f} (p={p:.3f})   clades {h}/{tot}   NN-purity {pur:.2f}")
    out.append("  TIER3 supervised probe (leave-1-family-out): held-out family recovered")
    for L in LAYERS:
        for k,(m,nt) in probe_loo(Cl[L],labels,fams,gold).items():
            out.append(f"    L{L:02d} PCA-{k}: {m*nt:.0f}/{nt} (mean {m:.2f})")
    txt="\n".join(out); print("\n"+txt); open("RESULT.txt","w").write(txt+"\n"); print("\n=== STATUS: DONE ===")

if __name__=="__main__": main()

"""076_repro / extract_singlecell -- WP1 job 4: the exp-068 SINGLE-CELL phase\n(Geneformer on PBMC3k), unchanged except cell-type centroids are saved to\n$OUT/singlecell_vectors.npz (the 068 run left no artifact on disk). NOTE: pins\ntransformers==4.46.3 -- run this LAST on a shared venv. Original docstring follows.\n\n"""
"""exp 068 SINGLE-CELL domain (Geneformer, self-supervised transcriptome MLM). PBMC3k immune cells:
a real cell-type differentiation hierarchy (lymphoid {CD4T,CD8T,B,NK} vs myeloid {Mono,DC}). Uses
Geneformer's own tokenizer + gene-symbol->Ensembl dict + pretrained model to embed cells, then the
three-tier metric-vs-topology test vs the cell-type hierarchy. Self-contained for jarvislabs GPU.
Diagnostic-heavy (this is the hard domain); iterate from logs."""
import subprocess, sys, os, pickle
# Geneformer pins no versions -> inherits box transformers 5.x which removed SpecialTokensMixin.
# Force last 4.x transformers (has it) + accelerate. Install geneformer last.
subprocess.run([sys.executable,"-m","pip","install","-q","scanpy","anndata","huggingface_hub",
                "transformers==4.46.3","accelerate",
                "git+https://huggingface.co/ctheodoris/Geneformer.git"],check=False)
import numpy as np
from pathlib import Path

IE_LYMPHOID={"CD4 T cells","CD8 T cells","B cells","NK cells"}
# louvain label -> (cell_type group, lineage supergroup)
LINEAGE={"CD4 T cells":("CD4T","Lymphoid"),"CD8 T cells":("CD8T","Lymphoid"),
         "B cells":("B","Lymphoid"),"NK cells":("NK","Lymphoid"),
         "CD14+ Monocytes":("CD14Mono","Myeloid"),"FCGR3A+ Monocytes":("FCGR3AMono","Myeloid"),
         "Dendritic cells":("DC","Myeloid"),"Megakaryocytes":("Mega","Mega")}

# ---- inlined three-tier (same as speech_phase) ----
class Node:
    def __init__(s,name=None,children=None): s.name=name; s.children=children or []
    def leaves(s):
        if not s.children: return [s.name]
        o=[]; [o.extend(c.leaves()) for c in s.children]; return o
def nj(labels,D):
    n=len(labels); act=[Node(name=L) for L in labels]; Dm=D.astype(float).copy(); np.fill_diagonal(Dm,0)
    while len(act)>2:
        m=len(act); rs=Dm.sum(1); Q=(m-2)*Dm-rs[:,None]-rs[None,:]; np.fill_diagonal(Q,np.inf)
        i,j=np.unravel_index(np.argmin(Q),Q.shape); i,j=(i,j) if i<j else (j,i)
        km=np.ones(m,bool); km[i]=km[j]=False; duk=0.5*(Dm[i,km]+Dm[j,km]-Dm[i,j])
        u=Node(children=[act[i],act[j]]); na=[act[k] for k in range(m) if k!=i and k!=j]+[u]
        sub=Dm[np.ix_(km,km)]; mn=m-1; Dm=np.zeros((mn,mn)); Dm[:mn-1,:mn-1]=sub; Dm[:mn-1,mn-1]=duk; Dm[mn-1,:mn-1]=duk; act=na
    return Node(children=act)
def bips(node,allL):
    parts=[]
    def rec(n):
        if not n.children: return
        for c in n.children:
            lb=frozenset(c.leaves())
            if 1<len(lb)<len(allL): parts.append(lb)
            rec(c)
    rec(node); return parts
def mantel(D1,D2,n_perms=2000,seed=0):
    n=D1.shape[0]; iu=np.triu_indices(n,1); v1,v2=D1[iu],D2[iu]; r=float(np.corrcoef(v1,v2)[0,1])
    rng=np.random.default_rng(seed); c=0
    for _ in range(n_perms):
        p=rng.permutation(n)
        if abs(np.corrcoef(v1,D2[np.ix_(p,p)][iu])[0,1])>=abs(r): c+=1
    return r,c/n_perms
def gold_from_groups(g,sup):
    n=len(g); D=np.zeros((n,n))
    for i in range(n):
        for j in range(n): D[i,j]=0 if i==j else (1 if g[i]==g[j] else (2 if sup[i]==sup[j] else 3))
    return D
def clades(labels,g,sup):
    cl=[frozenset(l for l,x in zip(labels,g) if x==G) for G in sorted(set(g))]
    cl+=[frozenset(l for l,x in zip(labels,sup) if x==S) for S in sorted(set(sup))]
    return [c for c in cl if 1<len(c)<len(labels)]
def dmat(C,kind):
    if kind=="euclid": return np.linalg.norm(C[:,None]-C[None],axis=2)
    Cn=C/np.clip(np.linalg.norm(C,axis=1,keepdims=True),1e-9,None); D=1-Cn@Cn.T; np.fill_diagonal(D,0); return D
def recovered(labels,D,cl):
    t=nj(list(labels),D); allL=frozenset(labels); b=set(bips(t,allL))
    return sum(1 for G in cl if G in b or (allL-G) in b), len(cl)
def nn_pur(D,g):
    hit=0
    for i in range(len(g)):
        d=D[i].copy(); d[i]=1e9; hit+=g[int(np.argmin(d))]==g[i]
    return hit/len(g)

def build_h5ad():
    import scanpy as sc, anndata as ad
    raw=sc.datasets.pbmc3k()                 # raw counts, gene symbols
    proc=sc.datasets.pbmc3k_processed()      # has obs['louvain'] cell types
    common=raw.obs_names.intersection(proc.obs_names)
    raw=raw[common].copy(); raw.obs["louvain"]=proc.obs.loc[common,"louvain"].values
    # map gene SYMBOL -> Ensembl via Geneformer's dict
    from geneformer import TranscriptomeTokenizer
    import geneformer, glob
    gdir=os.path.dirname(geneformer.__file__)
    cand=glob.glob(os.path.join(gdir,"*gene_name_id*"))+glob.glob(os.path.join(gdir,"gene_dictionaries*","*gene_name_id*"))
    print("gene_name_id dict candidates:",cand,flush=True)
    with open(cand[0],"rb") as f: sym2ens=pickle.load(f)
    ens=[sym2ens.get(g,None) for g in raw.var_names]
    keep=[i for i,e in enumerate(ens) if e is not None]
    raw=raw[:,keep].copy(); raw.var["ensembl_id"]=[ens[i] for i in keep]
    X=raw.X
    raw.obs["n_counts"]=np.asarray(X.sum(1)).ravel()
    raw.obs["cell_type"]=raw.obs["louvain"].astype(str).values
    raw=raw[raw.obs["cell_type"].isin(LINEAGE.keys())].copy()
    Path("scdata").mkdir(exist_ok=True); raw.write_h5ad("scdata/pbmc.h5ad")
    print("h5ad:",raw.shape,"celltypes:",raw.obs['cell_type'].value_counts().to_dict(),flush=True)
    return

def main():
    import torch
    from huggingface_hub import snapshot_download
    from geneformer import TranscriptomeTokenizer, EmbExtractor
    print("cuda",torch.cuda.is_available(),flush=True)
    build_h5ad()
    TranscriptomeTokenizer({"cell_type":"cell_type"},nproc=4).tokenize_data("scdata","sctok","pbmc",file_format="h5ad")
    mdl=snapshot_download("ctheodoris/Geneformer",allow_patterns=["Geneformer-V2-104M/*"])
    model_dir=os.path.join(mdl,"Geneformer-V2-104M")
    print("model_dir contents:",os.listdir(model_dir) if os.path.isdir(model_dir) else "MISSING",flush=True)
    # forward_batch_size 64 OOMs a 14.5GB T4 (the MLM head alone asks ~11GB);
    # 12 fits with headroom. Was sized for the 24GB L4.
    ex=EmbExtractor(model_type="Pretrained",num_classes=0,emb_mode="cell",
                    emb_label=["cell_type"],max_ncells=3000,emb_layer=-1,
                    forward_batch_size=12,nproc=4)
    os.makedirs("scout",exist_ok=True)
    df=ex.extract_embs(model_dir,"sctok/pbmc.dataset","scout","pbmc")
    emb_cols=[c for c in df.columns if isinstance(c,int) or str(c).isdigit()]
    print("emb df shape",df.shape,"n emb cols",len(emb_cols),flush=True)
    # per-cell-type centroid
    cts=sorted(df["cell_type"].unique())
    C=np.stack([df[df["cell_type"]==ct][emb_cols].values.mean(0) for ct in cts])
    _out=Path(os.environ.get("OUT","/home/out")); _out.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(_out/"singlecell_vectors.npz",C=C,cell_types=np.array(cts),
                        labels=np.array([LINEAGE[ct][0] for ct in cts]),
                        lineages=np.array([LINEAGE[ct][1] for ct in cts]))
    print(f"saved {_out}/singlecell_vectors.npz {C.shape}",flush=True)
    labels=[LINEAGE[ct][0] for ct in cts]; groups=labels; sup=[LINEAGE[ct][1] for ct in cts]
    gold=gold_from_groups(groups,sup); cl=clades(labels,groups,sup)
    out=[f"=== THREE-TIER [SINGLE-CELL Geneformer / PBMC3k] n={len(labels)} cell types, lineage hierarchy ===",
         f"  cell types: {labels}  lineages: {sup}",
         "  TIER1 unsupervised: metric -> Mantel(D,gold) | exact clades | NN same-celltype... (n small)"]
    for kind in ["euclid","cosine"]:
        D=dmat(C,kind); r,p=mantel(D,gold,2000); h,tot=recovered(labels,D,cl); pur=nn_pur(D,sup)
        out.append(f"    {kind:<8} r={r:+.3f} (p={p:.3f})   clades {h}/{tot}   NN same-lineage {pur:.2f}")
    txt="\n".join(out); print("\n"+txt); open("RESULT.txt","w").write(txt+"\n"); print("\n=== STATUS: DONE ===")

if __name__=="__main__": main()

"""Shared language set for the consolidation re-extraction (paper WP1).

LANGS = the exp-074 88-language table + ary_Arab (Moroccan Arabic), added so the
exp-033/043/048 Semitic member list [amh, arb, ary, heb, mlt] is fully covered.
Tuples are (flores_code, macrofamily, branch, genus).

FAM63 = the Phase-A per-family member lists (exp 043/048 FAM6) by 3-letter code —
the alignment sets used for the descent/clock numbers of record. Per-family
own-frame alignment depends on the member set (exp 035/037 lesson), so the
extraction stores centroids under BOTH this set and the full-88 family sets.

AGE/LINEAGE/CLOCK = the exp-048 dated lineages (the figure data's time axis).
WP3 replaces these with a cited dates.csv; kept here so the box can sanity-print.
"""

LANGS = [
 ("eng_Latn","IE","Germanic","WGermanic"),("deu_Latn","IE","Germanic","WGermanic"),
 ("nld_Latn","IE","Germanic","WGermanic"),("afr_Latn","IE","Germanic","WGermanic"),
 ("swe_Latn","IE","Germanic","NGermanic"),("dan_Latn","IE","Germanic","NGermanic"),
 ("nob_Latn","IE","Germanic","NGermanic"),("isl_Latn","IE","Germanic","NGermanic"),
 ("fra_Latn","IE","Romance","WRomance"),("spa_Latn","IE","Romance","WRomance"),
 ("por_Latn","IE","Romance","WRomance"),("cat_Latn","IE","Romance","WRomance"),
 ("glg_Latn","IE","Romance","WRomance"),("oci_Latn","IE","Romance","WRomance"),
 ("ita_Latn","IE","Romance","ItRomance"),("ron_Latn","IE","Romance","ERomance"),
 ("rus_Cyrl","IE","Slavic","ESlavic"),("ukr_Cyrl","IE","Slavic","ESlavic"),
 ("bel_Cyrl","IE","Slavic","ESlavic"),("bul_Cyrl","IE","Slavic","SSlavic"),
 ("mkd_Cyrl","IE","Slavic","SSlavic"),("slv_Latn","IE","Slavic","SSlavic"),
 ("hrv_Latn","IE","Slavic","SSlavic"),("srp_Cyrl","IE","Slavic","SSlavic"),
 ("pol_Latn","IE","Slavic","WSlavic"),("ces_Latn","IE","Slavic","WSlavic"),
 ("slk_Latn","IE","Slavic","WSlavic"),
 ("hin_Deva","IE","IndoAryan","CIndoAryan"),("urd_Arab","IE","IndoAryan","CIndoAryan"),
 ("ben_Beng","IE","IndoAryan","EIndoAryan"),("asm_Beng","IE","IndoAryan","EIndoAryan"),
 ("ory_Orya","IE","IndoAryan","EIndoAryan"),("mar_Deva","IE","IndoAryan","SIndoAryan"),
 ("guj_Gujr","IE","IndoAryan","WIndoAryan"),("pan_Guru","IE","IndoAryan","NWIndoAryan"),
 ("npi_Deva","IE","IndoAryan","NIndoAryan"),
 ("pes_Arab","IE","Iranian","WIranian"),("tgk_Cyrl","IE","Iranian","WIranian"),
 ("ckb_Arab","IE","Iranian","WIranian"),("pbt_Arab","IE","Iranian","EIranian"),
 ("ell_Grek","IE","Hellenic","Hellenic"),("hye_Armn","IE","Armenian","Armenian"),
 ("gle_Latn","IE","Celtic","Celtic"),("cym_Latn","IE","Celtic","Celtic"),
 ("lit_Latn","IE","Baltic","Baltic"),("lvs_Latn","IE","Baltic","Baltic"),
 ("tur_Latn","Turkic","Oghuz","Oghuz"),("azj_Latn","Turkic","Oghuz","Oghuz"),
 ("tuk_Latn","Turkic","Oghuz","Oghuz"),("uzn_Latn","Turkic","Karluk","Karluk"),
 ("kaz_Cyrl","Turkic","Kipchak","Kipchak"),("kir_Cyrl","Turkic","Kipchak","Kipchak"),
 ("bak_Cyrl","Turkic","Kipchak","Kipchak"),("tat_Cyrl","Turkic","Kipchak","Kipchak"),
 ("fin_Latn","Uralic","Finnic","Finnic"),("est_Latn","Uralic","Finnic","Finnic"),
 ("hun_Latn","Uralic","Ugric","Ugric"),
 ("arb_Arab","Afroasiatic","Semitic","Semitic"),("heb_Hebr","Afroasiatic","Semitic","Semitic"),
 ("amh_Ethi","Afroasiatic","Semitic","Semitic"),("mlt_Latn","Afroasiatic","Semitic","Semitic"),
 ("ary_Arab","Afroasiatic","Semitic","Semitic"),
 ("hau_Latn","Afroasiatic","Chadic","Chadic"),
 ("tam_Taml","Dravidian","SDravidian","SDravidian"),("tel_Telu","Dravidian","SCDravidian","SCDravidian"),
 ("kan_Knda","Dravidian","SDravidian","SDravidian"),("mal_Mlym","Dravidian","SDravidian","SDravidian"),
 ("zho_Hans","SinoTibetan","Sinitic","Sinitic"),("yue_Hant","SinoTibetan","Sinitic","Sinitic"),
 ("mya_Mymr","SinoTibetan","Burmish","Burmish"),
 ("jpn_Jpan","Japonic","Japonic","Japonic"),("kor_Hang","Koreanic","Koreanic","Koreanic"),
 ("ind_Latn","Austronesian","Malayic","Malayic"),("zsm_Latn","Austronesian","Malayic","Malayic"),
 ("tgl_Latn","Austronesian","Philippine","Philippine"),("ceb_Latn","Austronesian","Philippine","Philippine"),
 ("jav_Latn","Austronesian","Javanese","Javanese"),
 ("vie_Latn","Austroasiatic","Vietic","Vietic"),("khm_Khmr","Austroasiatic","Khmeric","Khmeric"),
 ("tha_Thai","KraDai","Tai","Tai"),("lao_Laoo","KraDai","Tai","Tai"),
 ("swh_Latn","AtlanticCongo","Bantu","Bantu"),("zul_Latn","AtlanticCongo","Bantu","Bantu"),
 ("xho_Latn","AtlanticCongo","Bantu","Bantu"),("sna_Latn","AtlanticCongo","Bantu","Bantu"),
 ("nya_Latn","AtlanticCongo","Bantu","Bantu"),("kin_Latn","AtlanticCongo","Bantu","Bantu"),
 ("yor_Latn","AtlanticCongo","VoltaNiger","VoltaNiger"),("ibo_Latn","AtlanticCongo","VoltaNiger","VoltaNiger"),
]

N, NTRAIN = 1012, 812

# Phase-A alignment sets (3-letter codes), exp 043/048 "FAM6".
FAM63 = {
    "Germanic":  ["afr", "dan", "deu", "eng", "isl", "nld", "swe"],
    "Romance":   ["cat", "fra", "glg", "ita", "por", "ron", "spa"],
    "Slavic":    ["bul", "ces", "hrv", "pol", "rus", "slk", "ukr"],
    "IndoAryan": ["ben", "guj", "hin", "mar", "npi", "urd"],
    "Semitic":   ["amh", "arb", "ary", "heb", "mlt"],
    "Turkic":    ["azj", "kaz", "kir", "tur"],
}

# exp-048 dated lineages (paper figure data's time axis; WP3 supersedes with dates.csv)
AGE = {"PRom": 1700, "ItaloW": 1500, "West": 1300, "Ibero": 1050,
       "PSlav": 1450, "East": 800, "WSlav": 1100, "CzSk": 600, "South": 1200,
       "PGerm": 2500, "North": 1300, "SweDan": 700, "WGerm": 1600,
       "ContW": 1100, "DutAfr": 350, "PTurk": 2000, "Oghuz": 900, "Kipchak": 700}
# WP3 cited-anchor variant of AGE (paper/data/dates_draft.csv). Sources:
# Chang et al. 2015 Language 91(1) Table 12; Holman et al. 2011 Curr.Anthropol.
# 52(6) calibration points. Nodes with no published anchor keep the 048 value.
# Two substantive corrections: CzSk 600 -> 1050 (Fodor 1962 via Holman; the 048
# value was ~2x off) and PTurk 2000 -> 1419 (the sampled Turkic langs are all
# COMMON Turkic -- no Chuvash -- so the node is Common Turkic, Golden 1998 via
# Holman, not the Proto-Turkic root).
AGE_CITED = {"PRom": 1750, "ItaloW": 1524, "West": 1300, "Ibero": 1050,
             "PSlav": 1500, "East": 760, "WSlav": 1100, "CzSk": 1050, "South": 1200,
             "PGerm": 2250, "North": 1500, "SweDan": 700, "WGerm": 1600,
             "ContW": 1100, "DutAfr": 350, "PTurk": 1419, "Oghuz": 900, "Kipchak": 900}
# Same, but with Holman's Scandinavian anchor (1100) instead of Chang's (1500):
# the one node where the two published anchors disagree materially.
AGE_CITED_ALT = dict(AGE_CITED, North=1100)

LINEAGE = {
    "ron": ["PRom"], "ita": ["PRom", "ItaloW"], "fra": ["PRom", "ItaloW", "West"],
    "spa": ["PRom", "ItaloW", "West", "Ibero"], "por": ["PRom", "ItaloW", "West", "Ibero"],
    "rus": ["PSlav", "East"], "ukr": ["PSlav", "East"], "pol": ["PSlav", "WSlav"],
    "ces": ["PSlav", "WSlav", "CzSk"], "slk": ["PSlav", "WSlav", "CzSk"],
    "bul": ["PSlav", "South"], "hrv": ["PSlav", "South"],
    "isl": ["PGerm", "North"], "swe": ["PGerm", "North", "SweDan"], "dan": ["PGerm", "North", "SweDan"],
    "eng": ["PGerm", "WGerm"], "deu": ["PGerm", "WGerm", "ContW"],
    "nld": ["PGerm", "WGerm", "ContW", "DutAfr"], "afr": ["PGerm", "WGerm", "ContW", "DutAfr"],
    "tur": ["PTurk", "Oghuz"], "azj": ["PTurk", "Oghuz"], "kaz": ["PTurk", "Kipchak"], "kir": ["PTurk", "Kipchak"]}
CLOCK = {"Romance": ["ron", "ita", "fra", "spa", "por"],
         "Slavic": ["rus", "ukr", "pol", "ces", "slk", "bul", "hrv"],
         "Germanic": ["isl", "swe", "dan", "eng", "deu", "nld", "afr"],
         "Turkic": ["tur", "azj", "kaz", "kir"]}


def short(code):
    """flores code -> 3-letter code (eng_Latn -> eng)."""
    return code.split("_")[0]


# Full-set family member lists (flores codes) for own-frame alignment: the six
# record families with every member the 89-set has, plus three new dense families.
FAM88 = {
    "Germanic":  ["eng_Latn","deu_Latn","nld_Latn","afr_Latn","swe_Latn","dan_Latn","nob_Latn","isl_Latn"],
    "Romance":   ["fra_Latn","spa_Latn","por_Latn","cat_Latn","glg_Latn","oci_Latn","ita_Latn","ron_Latn"],
    "Slavic":    ["rus_Cyrl","ukr_Cyrl","bel_Cyrl","bul_Cyrl","mkd_Cyrl","slv_Latn","hrv_Latn","srp_Cyrl","pol_Latn","ces_Latn","slk_Latn"],
    "IndoAryan": ["hin_Deva","urd_Arab","ben_Beng","asm_Beng","ory_Orya","mar_Deva","guj_Gujr","pan_Guru","npi_Deva"],
    "Semitic":   ["arb_Arab","heb_Hebr","amh_Ethi","mlt_Latn","ary_Arab"],
    "Turkic":    ["tur_Latn","azj_Latn","tuk_Latn","uzn_Latn","kaz_Cyrl","kir_Cyrl","bak_Cyrl","tat_Cyrl"],
    "Iranian":   ["pes_Arab","tgk_Cyrl","ckb_Arab","pbt_Arab"],
    "Dravidian": ["tam_Taml","tel_Telu","kan_Knda","mal_Mlym"],
    "Bantu":     ["swh_Latn","zul_Latn","xho_Latn","sna_Latn","nya_Latn","kin_Latn"],
}

"""076_repro / extract_language -- the consolidation re-extraction (paper WP1, job 1).

Rebuilds the lost exp-030 language cache at the exp-074 scale, in one artifact:
XLM-R-large over 89 FLORES-200 languages, layers {4,8,12,18} x {mean_pool, high_freq},
FLOAT32 end to end (the fp16 extraction instability is a documented artifact class;
this cache is the analysis-grade record).

Layer convention: layer_K = output of transformer block K (0-indexed) =
hidden_states[K+1], matching method/representations.py (the Phase-A numbers).

For every config it stores per-language TEST-split (last 200 sentences) centroids:
  raw_<cfg>     unaligned          (n, d)  -- norms carry the magnitude axis
  glob_<cfg>    global hub-aligned (n, d)  -- one shared frame, grand-mean removed
  famA_<fam>_<cfg> / famB_<fam>_<cfg>      -- per-family OWN-frame aligned:
        famA = the Phase-A alignment sets (FAM63, exp 033/043/048)
        famB = the full 89-set families (FAM88)
plus frag (subwords/char), surface_D (char_wb 3-5 TF-IDF, 1-cosine),
jac_D (1 - Jaccard of top-500 subword ids), codes, levels, meta (json).

Output: $OUT/language_reps.npz   (default /home/out). Download with jl download.
"""
import io, json, os, subprocess, sys, tarfile, time, urllib.request
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from langset import LANGS, FAM63, FAM88, N, NTRAIN, short  # noqa: E402
from hub import hub_align  # noqa: E402

FLORES_URL = "https://dl.fbaipublicfiles.com/nllb/flores200_dataset.tar.gz"
LAYERS = [4, 8, 12, 18]
POOLS = ["mean_pool", "high_freq"]
HIGH_FREQ_K = 80
MAXLEN = 256
BATCH = int(os.environ.get("BATCH", "24"))
OUT = Path(os.environ.get("OUT", "/home/out"))


def _extract_worker(dev, my_codes, lines, reps, frag, top500, prog, lock, t0, total, errs):
    """Per-device extraction worker: own tokenizer+model, fills the shared dicts
    (distinct keys per language -> thread-safe). Estimand-identical to the
    single-GPU loop; multi-GPU (Kaggle T4 x2) just shards languages."""
    try:
        import torch
        from transformers import AutoModel, AutoTokenizer
        tok = AutoTokenizer.from_pretrained("xlm-roberta-large")
        model = AutoModel.from_pretrained(
            "xlm-roberta-large", torch_dtype=torch.float32, output_hidden_states=True
        ).eval().to(dev)
        d = model.config.hidden_size
        specials = set(tok.all_special_ids)
        for c in my_codes:
            ls = lines[c]
            counts = Counter()
            ntok_all = 0
            for s in ls:
                ids = tok(s, add_special_tokens=False)["input_ids"]
                counts.update(ids)
                ntok_all += len(ids)
            for sid in specials:
                counts.pop(sid, None)
            hf_ids = {t for t, _ in counts.most_common(HIGH_FREQ_K)}
            acc = {(p, L): np.zeros((N, d), np.float32) for p in POOLS for L in LAYERS}
            for i in range(0, N, BATCH):
                enc = tok(ls[i:i + BATCH], return_tensors="pt", padding=True,
                          truncation=True, max_length=MAXLEN).to(dev)
                with torch.no_grad():
                    hs = model(**enc).hidden_states
                m = enc["attention_mask"].float()
                for sid in specials:
                    m[enc["input_ids"] == sid] = 0.0
                mh = m.clone()
                hf_mask = torch.zeros_like(m, dtype=torch.bool)
                for t in hf_ids:
                    hf_mask |= enc["input_ids"] == t
                mh[~hf_mask] = 0.0
                for L in LAYERS:
                    h = hs[L + 1]                     # layer_K = hidden_states[K+1]
                    mm = m.unsqueeze(-1)
                    acc[("mean_pool", L)][i:i + h.shape[0]] = (
                        (h * mm).sum(1) / mm.sum(1).clamp(min=1)).cpu().numpy()
                    mmh = mh.unsqueeze(-1)
                    pooled = (h * mmh).sum(1) / mmh.sum(1).clamp(min=1)
                    fallback = (h * mm).sum(1) / mm.sum(1).clamp(min=1)
                    empty = (mh.sum(1) == 0)
                    pooled[empty] = fallback[empty]
                    acc[("high_freq", L)][i:i + h.shape[0]] = pooled.cpu().numpy()
            with lock:
                top500[c] = {t for t, _ in counts.most_common(500)}
                frag[c] = ntok_all / max(sum(len(s) for s in ls), 1)
                for k in acc:
                    reps[k][c] = acc[k]
                prog[0] += 1
                if prog[0] % 10 == 0 or prog[0] == total:
                    print(f"  extracted {prog[0]}/{total} ({time.time()-t0:.0f}s)", flush=True)
        del model
        if str(dev).startswith("cuda"):
            torch.cuda.empty_cache()
    except Exception as e:  # surface in main; a silent dead thread would corrupt the cache
        errs.append((dev, e))
        raise


def get_flores() -> Path:
    root = Path("flores200_dataset")
    if not root.exists():
        tgz = Path("f.tgz")
        if not tgz.exists():
            req = urllib.request.Request(FLORES_URL, headers={"User-Agent": "Mozilla/5.0"})
            tgz.write_bytes(urllib.request.urlopen(req, timeout=600).read())
        with tarfile.open(tgz) as t:
            t.extractall(".")
    return root / "devtest"


def main():
    t0 = time.time()
    OUT.mkdir(parents=True, exist_ok=True)
    subprocess.run([sys.executable, "-m", "pip", "install", "-q",
                    "transformers", "sentencepiece", "scikit-learn"], check=False)
    import torch
    from transformers import AutoModel, AutoTokenizer

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    if dev != "cuda" and os.environ.get("ALLOW_CPU", "") != "1":
        raise SystemExit("refusing to run on CPU (set ALLOW_CPU=1 to override)")
    print(f"device={dev} batch={BATCH} maxlen={MAXLEN}", flush=True)

    dd = get_flores()
    codes = [c for c, _, _, _ in LANGS]
    lines = {}
    for c in codes:
        f = dd / f"{c}.devtest"
        assert f.exists(), f"FLORES missing {c}"
        ls = f.read_text(errors="ignore").splitlines()[:N]
        assert len(ls) == N, (c, len(ls))
        lines[c] = ls
    print(f"loaded {len(codes)} languages x {N} sentences", flush=True)

    import threading
    ngpu = torch.cuda.device_count() if dev == "cuda" else 0
    devs = [f"cuda:{i}" for i in range(ngpu)] or ["cpu"]
    print(f"extraction devices: {devs}", flush=True)

    reps = {(p, L): {} for p in POOLS for L in LAYERS}
    frag, top500 = {}, {}
    prog, lock, errs = [0], threading.Lock(), []
    if len(devs) == 1:
        _extract_worker(devs[0], codes, lines, reps, frag, top500,
                        prog, lock, t0, len(codes), errs)
    else:
        shards = [codes[i::len(devs)] for i in range(len(devs))]
        ths = [threading.Thread(target=_extract_worker,
                                args=(dv, sh, lines, reps, frag, top500,
                                      prog, lock, t0, len(codes), errs))
               for dv, sh in zip(devs, shards)]
        for th in ths:
            th.start()
        for th in ths:
            th.join()
    if errs:
        raise RuntimeError(f"extraction worker failed on {errs[0][0]}: {errs[0][1]!r}")
    assert len(frag) == len(codes), f"incomplete extraction: {len(frag)}/{len(codes)}"

    # surface + subword-inventory distances (model-free)
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    docs = [" ".join(lines[c]) for c in codes]
    Xs = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=2).fit_transform(docs)
    surface_D = 1.0 - cosine_similarity(Xs)
    np.fill_diagonal(surface_D, 0.0)
    nL = len(codes)
    jac_D = np.zeros((nL, nL))
    for i in range(nL):
        for j in range(i + 1, nL):
            a, b = top500[codes[i]], top500[codes[j]]
            jac_D[i, j] = jac_D[j, i] = 1.0 - len(a & b) / max(len(a | b), 1)
    print(f"surface + jaccard done ({time.time()-t0:.0f}s)", flush=True)

    arrs = {
        "codes": np.array(codes),
        "levels": np.array([(mf, br, ge, c) for c, mf, br, ge in LANGS]),
        "frag": np.array([frag[c] for c in codes]),
        "surface_D": surface_D,
        "jac_D": jac_D,
    }
    famA = {f: [c for c in codes if short(c) in ms] for f, ms in FAM63.items()}
    for f, ms in famA.items():
        arrs[f"famA_members_{f}"] = np.array(ms)
    for f, ms in FAM88.items():
        arrs[f"famB_members_{f}"] = np.array(ms)
    # exp-053/054's global frame: the 36 six-family languages, own joint
    # alignment (the record's +0.33..+0.44 cosine partial lives on THIS frame;
    # restricting the 89-frame attenuates it to ~0.29).
    f36 = [c for c in codes if short(c) in {m for ms in FAM63.values() for m in ms}]
    arrs["frame36_members"] = np.array(f36)

    for p in POOLS:
        for L in LAYERS:
            cfg = f"{p}_L{L:02d}"
            R = reps[(p, L)]
            arrs[f"raw_{cfg}"] = np.stack(
                [R[c][NTRAIN:].mean(0) for c in codes]).astype(np.float32)
            aligned, gm, _ = hub_align(R, n_train=NTRAIN)
            arrs[f"glob_{cfg}"] = np.stack(
                [aligned[c][NTRAIN:].mean(0) - gm for c in codes]).astype(np.float32)
            for tag, famset in (("famA", famA), ("famB", FAM88)):
                for f, ms in famset.items():
                    al, g, _ = hub_align({c: R[c] for c in ms}, n_train=NTRAIN)
                    arrs[f"{tag}_{f}_{cfg}"] = np.stack(
                        [al[c][NTRAIN:].mean(0) - g for c in ms]).astype(np.float32)
            al36, g36, _ = hub_align({c: R[c] for c in f36}, n_train=NTRAIN)
            arrs[f"glob36_{cfg}"] = np.stack(
                [al36[c][NTRAIN:].mean(0) - g36 for c in f36]).astype(np.float32)
            print(f"aligned {cfg} ({time.time()-t0:.0f}s)", flush=True)

    meta = dict(model="xlm-roberta-large", dtype="float32", maxlen=MAXLEN,
                batch=BATCH, layers=LAYERS, pools=POOLS, high_freq_k=HIGH_FREQ_K,
                layer_convention="layer_K == hidden_states[K+1] (block K output)",
                centroid="test-split (last 200) mean; aligned variants minus grand mean",
                n=N, ntrain=NTRAIN, date="2026-08-24")
    arrs["meta"] = np.array(json.dumps(meta))
    out = OUT / "language_reps.npz"
    np.savez_compressed(out, **arrs)
    print(f"wrote {out} ({out.stat().st_size/1e6:.1f} MB)", flush=True)

    # sanity: same-branch NN purity on glob mean_pool L12 cosine
    X = arrs["glob_mean_pool_L12"].astype(np.float64)
    Xn = X / np.linalg.norm(X, axis=1, keepdims=True)
    Dc = 1 - Xn @ Xn.T
    np.fill_diagonal(Dc, np.inf)
    br = [l[1] for l in arrs["levels"]]
    nn = Dc.argmin(1)
    pur = np.mean([br[i] == br[nn[i]] for i in range(nL)])
    print(f"SANITY glob mean_pool_L12 cosine same-branch NN purity = {pur:.3f} "
          f"(chance ~{np.mean([ (np.array(br)==b).mean() for b in br]):.3f})", flush=True)
    assert pur > 0.3, "NN purity implausibly low -- extraction suspect"
    print(f"=== STATUS: DONE ({time.time()-t0:.0f}s) ===", flush=True)


if __name__ == "__main__":
    main()
